// inject.js — tourne dans le "MAIN world" de la page vinted.fr (le meme monde
// que le JavaScript du site), ce qui permet d'observer les vraies requetes que
// la page fait deja. On NE declenche AUCUNE requete : on se contente de
// regarder passer ce que Vinted envoie deja au navigateur quand tu navigues.
//
// Deux choses capturees :
//   1) le header 'x-csrf-token' des requetes (introuvable autrement) ;
//   2) le CORPS des reponses des endpoints utiles (annonces, ventes, messages,
//      profil) — c'est la "capture passive" : la donnee est deja la, on la lit.
//
// Tout est renvoye a content.js via window.postMessage (le seul canal entre le
// MAIN world et l'extension).
(function () {
  'use strict';
  if (window.__cancaleVintedInjected) return;
  window.__cancaleVintedInjected = true;

  const TAG = 'CANCALE_VINTED';

  // Endpoints dont on veut garder la reponse, avec le "type" de donnee associe.
  // ⚠️ Motifs volontairement TOLÉRANTS à la version d'API (v2, v3, …). Vinted a
  // migré une partie de son site vers /api/v3/ : les motifs figés sur /api/v2/
  // ne captaient plus rien pour les annonces / commandes / boîte de réception
  // (moisson bloquée pendant 18 jours sans que personne ne s'en aperçoive).
  const HARVEST = [
    { re: /\/api\/v\d+\/wardrobe\/(\d+)\/items/, type: 'listings' },
    // Variante « dressing » : certaines versions listent les articles d'un
    // utilisateur via /items?user_id=… au lieu de /wardrobe/{id}/items.
    { re: /\/api\/v\d+\/items\?[^]*user_id=(\d+)/, type: 'listings' },
    // Détail COMPLET d'un article : /api/v2/items/{id} → titre, DESCRIPTION,
    // marque, taille, état, couleur, matière, CATÉGORIE (catalog_id), dimensions
    // du colis, photos HD. Capté passivement quand tu ouvres une de tes annonces
    // (et complété activement, voir plus bas) → l'app a TOUT pour la republier.
    { re: /\/api\/v\d+\/items\/(\d+)(?:\?|$)/,   type: 'item'     },
    { re: /\/api\/v\d+\/my_orders/,             type: 'orders'   },
    { re: /\/api\/v\d+\/(?:inbox|conversations)(?:\?|$)/, type: 'inbox' },
    // (29 octobre) Une conversation a aussi un identifiant UUID : celui que
    // portent les commandes (`conversation_id`, 36 caractères, mesuré en base) ;
    // une page qui charge la conversation par lui n'était jamais captée. Et la
    // règle est ANCRÉE : `…/conversations/{id}` seul (ou suivi d'une requête),
    // jamais un sous-chemin (`…/replies`, `…/mark_as_read`), dont la réponse
    // n'est pas une conversation. Le fond range la conversation sous l'id
    // NUMÉRIQUE que porte la réponse (`storeHarvest`), jamais sous l'UUID.
    { re: /\/api\/v\d+\/conversations\/(\d+|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\/?(?:\?|$)/i, type: 'conversation' },
    // Détail d'une transaction (vente/achat) : son ÉTAT (`status`, `status_title`,
    // `shipment {id, status, status_title, status_updated_at}`), capté passivement
    // quand tu ouvres une commande ou télécharges un bordereau. On ne matche QUE le
    // détail (…/transactions/{id}), pas les sous-chemins (…/shipment/order).
    // ⚠️⚠️ (23 octobre) CE COMMENTAIRE DISAIT QUE LE N° DE SUIVI DU TRANSPORTEUR
    //    ÉTAIT ICI (« shipment / tracking_code ») : FAUX, mesuré en lecture seule —
    //    0 n° de suivi sur 1 290 transactions captées, 0 dans 1 400 conversations,
    //    0 dans les commandes. Le suivi que Vinted MONTRE de ses achats (le bouton
    //    « Suivre le colis ») passe par `…/shipment/journey_summary` : voir
    //    `noteSuivi` plus bas (5.214).
    { re: /\/api\/v\d+\/transactions\/(\d+)(?:\?|$)/, type: 'transaction' },
    { re: /\/api\/v\d+\/users\/current/,        type: 'profile'  },
    // NOTIFICATIONS VINTED (la cloche) — 30 septembre. Mesuré par l'observation
    // de Vintex : c'est là que Vinted dit QUI a mis un article en favori
    // (« X a marqué ton article Y comme favori »), avec le pseudo. §3 disait
    // « Vinted ne dit jamais qui met en favori » : faux pour ce flux-là.
    // L'extension n'avait JAMAIS vu cette adresse (0 dans seen_urls). On garde
    // la réponse telle quelle quand la page la charge (ouvrir la cloche), pour
    // MESURER sa forme avant d'écrire la moindre règle dessus.
    // Le service inbox-notifications vit hors /api/. Son comptage seul
    // (unread_count) n'est pas une liste et ne remplace jamais la capture.
    // Le rapprochement favoris/conversation reste à vérifier sur le vrai flux.
    // LITIGES / RÉCLAMATIONS. Quand un acheteur ouvre un litige, la paire te
    // revient (ou pas) et il faut la republier — mais Vinted ne le dit que dans
    // cet écran. On capte la LISTE et le DÉTAIL, passivement, quand tu ouvres la
    // page « Litiges » ou une conversation en litige : l'app peut alors afficher
    // le vrai motif et le vrai statut au lieu de les déduire du statut de vente.
    { re: /\/api\/v\d+\/complaints(?:\?|$)/,     type: 'complaints' },
    { re: /\/api\/v\d+\/complaints\/(\d+)(?:\?|$)/, type: 'complaint' },
    // Facturation / porte-monnaie : c'est là que Vinted liste tes dépenses de
    // BOOST (remontées d'annonce, mise en avant du dressing). Capté passivement
    // quand tu ouvres ton porte-monnaie / ta facturation → l'app calcule ton
    // bénéfice NET tout seul. Motif large (plusieurs noms selon la version).
    { re: /\/(wallet|invoices?|billing|bumps?|item_bumps|push_ups?|dressing_spotlight|vas_entries|payments?)/i, type: 'billing' },
    // Points relais que Vinted te propose quand tu choisis un relais (achat) :
    // c'est SA liste officielle, complète, autour de l'adresse de livraison. On
    // la capte passivement pour l'afficher sur la carte. Motif large (Vinted a
    // plusieurs noms d'endpoint selon le transporteur / la version).
    { re: /pickup[_-]?points?|pudo|drop[_-]?off[_-]?points?|shipping[_-]?points?|parcel[_-]?shops?|point[_-]?of[_-]?delivery|delivery[_-]?points?/i, type: 'pickup_points' },
    // DÉTAIL D'UNE EXPÉDITION — « où vais-je chercher ce colis ? ».
    // ⚠️ Mesuré : la transaction ne porte QUE `shipment {id,status,status_title,
    // status_updated_at}` — aucune adresse (§16, reconfirmé aujourd'hui). Et les
    // 2 colis réellement à retirer n'ont AUCUN email de suivi, donc ni code ni
    // lieu : c'est exactement « je ne sais pas où aller chercher mes colis ».
    // La transaction donne pourtant le `shipment.id`, et Vinted sert bien des
    // `/shipments/{id}/…` (vus dans seen_urls). On capte donc le détail quand la
    // page de suivi le charge — une ligne PAR COLIS (`ship_{id}`), sinon un colis
    // écraserait le précédent.
    // ⚠️ Borné à `(?:\?|$)` : les sous-chemins (label_url, label_options,
    // nearby_drop_off_points) ont déjà leur propre traitement, il ne faut pas
    // que ce motif les avale.
    { re: /\/api\/v\d+\/shipments\/(\d+)(?:\?|$)/, type: 'shipment' },
  ];
  const adresseNotificationsVinted = (url) => {
    try {
      const u = new URL(url, location.origin);
      if (u.protocol !== 'https:' || u.username || u.password || !/^(?:(?:www|api)\.)?vinted\.(?:fr|com|it|de)$/i.test(u.hostname)) return null;
      return u;
    } catch (_) { return null; }
  };
  const listeNotificationsVinted = (url) => {
    const u = adresseNotificationsVinted(url);
    return !!u && /^\/(?:api\/v\d+\/(?:user_)?notifications|inbox-notifications\/v\d+\/notifications)\/?$/i.test(u.pathname);
  };
  const traceNotificationsVinted = (url) => {
    const u = adresseNotificationsVinted(url);
    return !!u && /^\/(?:api\/v\d+\/(?:user_)?notifications|inbox-notifications\/v\d+\/notifications)(?:\/|$)/i.test(u.pathname);
  };
  const matchHarvest = (url) => {
    if (listeNotificationsVinted(url)) return {type:'notifications',id:null};
    for (const h of HARVEST) {
      const m = h.re.exec(url);
      if (!m) continue;
      let type = h.type;
      // Pour les commandes, on distingue achats et ventes via le param ?type=
      // (ex: my_orders?type=sold -> "orders_sold"), sinon elles s'ecraseraient.
      if (type === 'orders') {
        const t = /[?&]type=([^&]+)/.exec(url);
        // Sans ?type=, la reponse MELANGE ventes et achats : la ranger
        // produirait une ligne ambigue que l'app ne peut pas departager (elle
        // affichait alors des achats dans les ventes). On ne la garde pas.
        if (!t) return null;
        const raw = decodeURIComponent(t[1]).toLowerCase();
        // ⚠️ On NE range QUE les deux clefs canoniques : orders_sold (ventes) et
        // orders_purchased (achats). Le param ?type=bought renvoie chez certains
        // comptes les VENTES (verifie en base) : rangee en "orders_bought", cette
        // ligne faisait afficher des ventes dans les achats. On l'ignore, ainsi
        // que tout autre type inconnu.
        if (/sold|sell/.test(raw)) type = 'orders_sold';
        else if (raw === 'purchased' || raw === 'purchases') type = 'orders_purchased';
        else return null;
      }
      return { type, id: m[1] || null };
    }
    return null;
  };

  const post = (payload) => {
    try { window.postMessage(Object.assign({ __tag: TAG }, payload), '*'); } catch (_) {}
  };

  // Bind the native creation to the exact favorite link the user opened.
  // Passive observation only; no navigation and no message is initiated here.
  const lienContexteFavori = v => {
    try { const u=new URL(v,location.origin);u.hash='';
      return u.protocol==='https:'&&!u.username&&!u.password&&/^(?:www\.)?vinted\.(fr|com|it|de)$/.test(u.hostname)&&/^\/items\/[1-9]\d{0,19}\/[a-z_-]{1,40}\/new\/?$/.test(u.pathname)&&u.href.length<=2000?u.href:null;
    }catch{return null;}
  };
  let dernierFavoriClique=null;
  window.addEventListener('click',e=>{
    dernierFavoriClique=null;if(!e.isTrusted)return;
    const a=e.target?.closest?.('a[href]'),url=a&&lienContexteFavori(a.href);
    if(url)dernierFavoriClique={url,at:Date.now()};
    // The bell renders favorites as ?receiver_id=&item_id= (measured 25-26 Oct).
    // Only the URL goes to the extension; it checks everything itself.
    else if(a){try{const v=new URL(a.href,location.origin);if(v.origin===location.origin&&v.searchParams.has('receiver_id')&&v.searchParams.has('item_id')&&v.href.length<=2000)post({kind:'favoriNatifClic',url:v.href});}catch{}}
  },true);

function suivreFavoriAffiche(cible,activer=false){
 const normaliser=v=>{try{const u=new URL(v,location.href);if(u.origin!==location.origin)return null;u.hash='';u.searchParams.sort();return u.href;}catch{return null;}};
 const attendu=normaliser(cible);if(!attendu)return {trouve:false};
 const item=v=>{try{return /^\/items\/([1-9]\d{0,19})\/[a-z_-]{1,40}\/new\/?$/.exec(new URL(v).pathname)?.[1]||'';}catch{return '';}};
 const rectVisible=e=>[...e.getClientRects()].some(r=>r.width>0&&r.height>0);
 const visible=a=>{
  if(a.closest('[inert],[aria-hidden="true"]')||getComputedStyle(a).visibility==='hidden'||getComputedStyle(a).display==='none')return false;
  // display:contents anchors have no own rectangle although their content is
  // visible and clickable. Do not reject their native links for this reason.
  return rectVisible(a)||(getComputedStyle(a).display==='contents'&&[...a.querySelectorAll('*')].some(e=>getComputedStyle(e).visibility!=='hidden'&&rectVisible(e)));
 };
 const tous=[...document.querySelectorAll('a[href]')].slice(0,10000).map(a=>({a,url:normaliser(a.href)}));
 const exacts=tous.filter(x=>x.url===attendu),liens=exacts.filter(x=>visible(x.a));
 // Native bell rows may render the same favorite as ?receiver_id=&item_id=
 // (measured on the seller's real page, 25 Oct). Accepted only by identity:
 // same article, and receiver_id equal to the single numeric parameter of the
 // captured link. Exactly these two keys, once each, numeric; messaging route.
 const num=v=>typeof v==='string'&&/^[1-9]\d{0,19}$/.test(v)?v:'';
 const article=item(attendu);let destinataire='';
 try{const p=new URL(attendu).searchParams,ks=[...p.keys()];if(ks.length===1&&p.getAll(ks[0]).length===1&&num(p.get(ks[0]))!==article)destinataire=num(p.get(ks[0]));}catch{}
 const natif=url=>{try{
  const u=new URL(url),p=u.searchParams,ks=[...p.keys()].sort();
  if(ks.join(',')!=='item_id,receiver_id'||p.getAll('item_id').length!==1||p.getAll('receiver_id').length!==1)return null;
  const it=num(p.get('item_id')),re=num(p.get('receiver_id'));if(!it||!re)return null;
  if(!/^\/(?:inbox|conversations?|messages?)(?:\/[a-z_-]{1,40}){0,2}\/?$/.test(u.pathname)&&!new RegExp('^/items/'+it+'/[a-z_-]{1,40}(?:/new)?/?$').test(u.pathname))return null;
  return {chemin:u.pathname.replace(/\/$/,'')||'/',itemId:it,receiverId:re};
 }catch{return null;}};
 const natifs=tous.map(x=>({...x,n:x.url&&natif(x.url)})).filter(x=>x.n),natifsArticle=natifs.filter(x=>x.n.itemId===article);
 const candidats=destinataire?natifsArticle.filter(x=>x.n.receiverId===destinataire):[],candidatsVisibles=candidats.filter(x=>visible(x.a));
 const inspection={liensFavoris:tous.filter(x=>x.url&&item(x.url)).length,memeArticle:tous.filter(x=>x.url&&item(x.url)===article).length,exacts:exacts.length,visibles:liens.length,natifsMemeArticle:natifsArticle.length,natifs:candidats.length,natifsVisibles:candidatsVisibles.length};
 if(exacts.length){
  if(liens.length!==1)return {trouve:false,inspection};
  if(activer){liens[0].a.scrollIntoView({block:'center'});liens[0].a.click();}
  return {trouve:true,inspection};
 }
 // Exactly one visible candidate; two (even same href) is refused, as above.
 if(candidatsVisibles.length!==1)return {trouve:false,inspection};
 if(activer){candidatsVisibles[0].a.scrollIntoView({block:'center'});candidatsVisibles[0].a.click();}
 return {trouve:true,inspection,natif:candidatsVisibles[0].n};
}
// Semantic native controls only. No guessed CSS class, router or API call.
function clocheFavorisNative(activer=false,origine){
 if(location.origin!==origine)return {etat:'origine'};
 const label=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
 const reconnu=v=>/^(?:(?:mes|my|le mie|meine) |(?:(?:ouvrir|afficher|voir|open|show|view) (?:les |the )?))?(?:notifications?|notifiche|benachrichtigungen)(?:\s*[:·,–-]?\s*\(?[0-9]{1,5}\+?\)?(?: (?:non lues?|unread|non lette|ungelesen))?)?$/.test(label(v));
 const nom=b=>{
  // Follow accessible-name precedence. A labelled child must not override an
  // explicit parent label (e.g. a destructive control containing an icon).
  const ids=(b.getAttribute('aria-labelledby')||'').trim().split(/\s+/).filter(Boolean);
  if(ids.length){const refs=ids.map(id=>document.getElementById(id));if(refs.some(x=>!x))return '';return refs.map(x=>x.textContent||'').join(' ');}
  if(b.hasAttribute('aria-label'))return b.getAttribute('aria-label');
  const texte=(b.innerText||'').trim();if(texte)return texte;
  return b.getAttribute('title')||b.querySelector('svg title')?.textContent||'';
 };
 const boutons=[...document.querySelectorAll('button,[role="button"],a[href]')].filter(b=>{
  if(!b.getClientRects().length||getComputedStyle(b).visibility==='hidden'||getComputedStyle(b).display==='none'||b.closest('[inert],[aria-hidden="true"]'))return false;
  if(b.tagName==='A'){try{const u=new URL(b.href,location.href);if(u.origin!==origine||u.protocol!=='https:')return false;}catch{return false;}}
  if(b.tagName==='BUTTON'&&b.form&&b.type==='submit')return false;
  return reconnu(nom(b));
 });
 if(boutons.length!==1)return {etat:boutons.length?'ambigue':'absente'};
 const b=boutons[0];if(b.disabled||b.getAttribute('aria-disabled')==='true')return {etat:'indisponible'};
 const ouverte=b.getAttribute('aria-expanded')==='true';
 if(activer&&!ouverte)b.click();
 return {etat:ouverte?'deja_ouverte':activer?'activee':'disponible'};
}

  // Navigation relay for browsers without scripting. No eval or network request.
  const navFavorisReponses=new Map();
  window.addEventListener('message',event=>{
    const m=event.data;if(window.top!==window||event.source!==window||!m||m.__tag!=='CANCALE_VINTED_FAVORI_REQ'||!/^f[a-f0-9]{32}$/.test(String(m.id||'')))return;
    if(!['sonder','ouvrir','cloche_sonder','cloche_ouvrir'].includes(m.action))return;
    let u;try{u=new URL(m.cible);if(u.origin!==location.origin||!lienContexteFavori(u.href))return;}catch{return;}
    const ancien=navFavorisReponses.get(m.id);
    if(ancien){if(ancien.action===m.action&&ancien.cible===u.href)window.postMessage(ancien.reponse,location.origin);return;}
    let resultat;
    try{resultat=m.action.startsWith('cloche_')?clocheFavorisNative(m.action==='cloche_ouvrir',u.origin):suivreFavoriAffiche(u.href,m.action==='ouvrir');}catch{return;}
    const reponse={__tag:'CANCALE_VINTED_FAVORI_REP',id:m.id,origine:location.origin,resultat};
    navFavorisReponses.set(m.id,{action:m.action,cible:u.href,reponse});while(navFavorisReponses.size>64)navFavorisReponses.delete(navFavorisReponses.keys().next().value);
    window.postMessage(reponse,location.origin);
  });
  let lastCsrf = null; // dernier x-csrf-token vu (réutilisé pour la moisson active)
  let lastAnon = null; // dernier x-anon-id vu
  const sendCsrf = (headers) => {
    try {
      let csrf = null;
      if (headers instanceof Headers) { csrf = headers.get('x-csrf-token'); const a = headers.get('x-anon-id'); if (a) lastAnon = a; }
      else if (headers && typeof headers === 'object') {
        for (const k in headers) { const kl = k.toLowerCase(); if (kl === 'x-csrf-token') csrf = headers[k]; else if (kl === 'x-anon-id') lastAnon = headers[k]; }
      }
      if (csrf) { lastCsrf = csrf; post({ kind: 'csrf', csrf }); }
    } catch (_) {}
  };

  // MOUCHARD D'ENDPOINTS (diagnostic). On note UNIQUEMENT le chemin des appels
  // API que la page fait (jamais le contenu, jamais les paramètres). Ça permet
  // de voir tout de suite quand Vinted renomme/déplace un endpoint, au lieu de
  // découvrir des semaines plus tard que la moisson est muette. Envoyé au plus
  // une fois par minute, liste dédupliquée.
  const seenPaths = new Set();
  const seenRep = {};                    // "METHOD /chemin" → { st, n }
  let seenDirty = false;
  // ⚠️⚠️ POURQUOI LE CODE DE RÉPONSE, ET POURQUOI LES PAGES NON-API.
  // Demande de Julien, 19 septembre : son compte PRO est bloqué, et le bouton
  // « télécharger mes données » des réglages Vinted le renvoie sur « ton compte
  // est bloqué ». Impossible de savoir, de l'extérieur, si la requête d'export
  // PART et se fait refuser par le serveur (403 → aucun contournement côté
  // navigateur ne servira) ou si elle n'est jamais envoyée parce que c'est
  // seulement la page qui redirige (→ la donnée est peut-être atteignable). Les
  // deux cas n'appellent pas du tout le même geste, et les distinguer demande
  // **le statut**, que ce mouchard ne notait pas. Il ne notait pas non plus les
  // adresses hors `/api/` : une page de réglages ne laissait donc aucune trace.
  // ⚠️ La promesse de confidentialité ne change pas : chemin + méthode + statut,
  //    JAMAIS le contenu, jamais les paramètres — les identifiants numériques
  //    sont même remplacés par `{id}` (voir `chemin()`).
  const PAGE_A_NOTER = /(export|download|telecharg|takeout|gdpr|rgpd|privacy|donnees|data|settings|parametres|reglages|account|compte|blocked|bloque|suspend|restrict)/i;
  // <chemin-regle> (29 octobre) — la MÊME dans la page et dans le fond (§11).
  // Mesuré en base : les pages d'une conversation appellent un contrôle
  // anti-hameçonnage dont le chemin porte un UUID, qui passait EN CLAIR dans
  // `seen_urls` (17 à 55 clés de ce genre par compte) — un identifiant réel, et
  // une clé de plus par conversation ouverte. Un UUID devient `{uuid}`, une
  // longue suite hexadécimale `{hex}`, un nombre de 3 chiffres ou plus `{id}`.
  function cheminNormalise(p) {
    return String(p == null ? '' : p)
      .replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, '{uuid}')
      .replace(/\/(?=[0-9a-f]*\d)[0-9a-f]{20,}(?=\/|$)/gi, '/{hex}')
      .replace(/\/\d{3,}/g, '/{id}');
  }
  // </chemin-regle>
  const chemin = (url) => {
    let p = url;
    try { p = new URL(url, location.origin).pathname; } catch (_) { p = String(url).split('?')[0]; }
    return cheminNormalise(p);                     // jamais un identifiant réel
  };
  const noteSeen = (url, method, status) => {
    try {
      const estApi = /\/api\//.test(url || '');
      const p = chemin(url || '');
      // Hors API, on ne note que ce qui peut concerner un export ou le compte :
      // tout noter ferait une liste de bruit, et §7 vaut aussi pour un diagnostic.
      if (!estApi && !PAGE_A_NOTER.test(p) && !traceNotificationsVinted(url)) return;
      if (!seenPaths.has(p)) { seenPaths.add(p); seenDirty = true; }
      if (status == null) return;
      const cle = `${String(method || 'GET').toUpperCase()} ${p}`;
      const av = seenRep[cle];
      // On garde le dernier statut vu et combien de fois : « 403 une fois » et
      // « 403 à chaque essai » ne se lisent pas pareil.
      if (!av || av.st !== Number(status)) seenDirty = true;
      seenRep[cle] = { st: Number(status), n: ((av && av.n) || 0) + 1, at: new Date().toISOString() };
      // ⚠️⚠️ UNE PAGE QUI REBONDIT N'ATTEINT JAMAIS LE VIDAGE À 5 s.
      // Mesuré le 19 septembre : il a cliqué sur « télécharger mes infos » avec
      // son compte bloqué, la page l'a renvoyé aussitôt sur « compte bloqué »,
      // et le relevé de CETTE page n'est jamais parti — seuls les chemins de la
      // page d'avant (son dressing) ont été rangés. `pagehide` ne suffit pas :
      // un `sendMessage` depuis une page qui se décharge part rarement.
      // ⇒ Ce qui est INTÉRESSANT s'envoie sur-le-champ : un appel qui ÉCHOUE
      //   (≥ 400), ou un appel sur un chemin de compte/export. C'est justement
      //   le cas où la page ne nous laisse pas le temps.
      try { if (Number(status) >= 400 || PAGE_A_NOTER.test(p) || traceNotificationsVinted(url)) setTimeout(flushSeen, 0); } catch (_) {}
    } catch (_) {}
  };
  // ═══ LA PAGE D'UNE CONVERSATION : PAR OÙ PASSENT LES MESSAGES ? (29 oct.) ═══
  // Mesuré en lecture seule (sa base) : depuis le 18 octobre, PLUS AUCUNE
  // requête `/api/v2/conversations/…` (ni `mark_as_read`) ne part de la page
  // d'une conversation. On n'y voit que l'escrow, les bannières, les litiges et
  // un contrôle anti-hameçonnage. Les messages arrivent donc par une route
  // qu'on ne connaît pas : hors `/api/` (que `noteSeen` ignore), une socket, un
  // flux d'évènements, ou les données de la page (Next). ON NE LA DEVINE PAS.
  // Sur la page d'une conversation seulement, on relève :
  //   · chaque requête de la page vers Vinted (méthode, chemin NORMALISÉ,
  //     statut, type de contenu), y compris hors `/api/` ;
  //   · pour une réponse qui PORTE une liste de messages, sa FORME : où elle
  //     est, combien, les noms de clés de ses éléments et leur type — jamais
  //     une valeur ; et, pour une réponse JSON, les clés de tête (forme) ;
  //   · l'ouverture d'une socket (WebSocket) ou d'un flux (EventSource), sur
  //     toute page de Vinted : hôte et chemin normalisé (jamais la requête),
  //     combien de trames, la forme de la première trame JSON et celle d'une
  //     trame qui porte des messages ;
  //   · si la page porte des données Next (`__NEXT_DATA__`, `self.__next_f`)
  //     et si elles parlent de messages (oui / non, jamais leur texte).
  // Le relevé part avec `seen_urls` (ligne `harvest_{uid}_seen_urls`, clé
  // `conversation`). AUCUNE requête de plus ; bornes par construction.
  const PAGE_CONV = /^\/(?:inbox|conversations?|messages?)(?:\/|$)/i;
  const surPageConv = () => { try { return PAGE_CONV.test(location.pathname); } catch (_) { return false; } };
  const hoteVinted = (h) => /(?:^|\.)vinted\.[a-z.]{2,6}$/i.test(String(h || ''));
  const relConv = { req: {}, canaux: {}, pages: {}, next: null };
  let relConvDirty = false;
  const REL_CONV_REQ_MAX = 60, REL_CONV_CANAUX_MAX = 12, REL_CONV_PAGES_MAX = 10;
  const MOTIF_MESSAGES_TEXTE = /"messages"\s*:\s*\[|\\"messages\\"\s*:\s*\[/;
  const typeDe = (v) => (v === null ? 'null' : Array.isArray(v) ? 'array' : typeof v);
  // Une clé d'objet n'est relevée que si elle a la forme d'un NOM de champ ;
  // un identifiant (UUID, nombre) devient un repère, le reste `{x}`.
  const cleForme = (k) => {
    const t = String(k);
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(t)) return '{uuid}';
    if (/\d{3,}/.test(t)) return '{id}';
    return /^[A-Za-z_$][\w$-]{0,39}$/.test(t) ? t : '{x}';
  };
  // Les clés de tête d'un JSON (deux niveaux), avec leur type.
  const formeTete = (racine) => {
    const out = {};
    if (!racine || typeof racine !== 'object') return { racine: typeDe(racine) };
    const tete = Array.isArray(racine) ? { '[]': racine[0] } : racine;
    // Bornée (30 clés) : le relevé entier doit rester bien sous les 200 000
    // caractères que le fond accepte, sinon il serait jeté en entier.
    for (const k of Object.keys(tete).slice(0, 20)) {
      const ck = cleForme(k), v = tete[k];
      out[ck] = typeDe(v);
      if (v && typeof v === 'object' && !Array.isArray(v)) for (const k2 of Object.keys(v).slice(0, 10)) { if (Object.keys(out).length >= 30) break; out[ck + '.' + cleForme(k2)] = typeDe(v[k2]); }
      if (Object.keys(out).length >= 30) break;
    }
    return out;
  };
  // Une liste (non vide) d'OBJETS rangée sous une clé « message(s) », à six
  // niveaux au plus : sa place, sa longueur, et la forme de ses éléments.
  const formeMessages = (racine) => {
    const file = [[racine, '', 0]];
    let vus = 0, trouve = null;
    while (file.length && vus < 4000 && !trouve) {
      const [v, ch, d] = file.shift(); vus++;
      if (!v || typeof v !== 'object' || d > 6) continue;
      if (Array.isArray(v)) { for (const x of v.slice(0, 3)) file.push([x, ch + '[]', d + 1]); continue; }
      for (const k of Object.keys(v).slice(0, 200)) {
        const x = v[k], c = ch ? ch + '.' + cleForme(k) : cleForme(k);
        if (/^messages?$/i.test(k) && Array.isArray(x) && x.some((e) => e && typeof e === 'object' && !Array.isArray(e))) { trouve = { chemin: c, liste: x }; break; }
        if (x && typeof x === 'object') file.push([x, c, d + 1]);
      }
    }
    if (!trouve) return null;
    const cles = {};
    for (const e of trouve.liste.slice(0, 20)) {
      if (!e || typeof e !== 'object' || Array.isArray(e)) continue;
      for (const k of Object.keys(e).slice(0, 60)) {
        const ck = cleForme(k), ty = typeDe(e[k]);
        if (!cles[ck]) cles[ck] = ty; else if (!cles[ck].split('|').includes(ty)) cles[ck] = (cles[ck] + '|' + ty).slice(0, 40);
        const sous = e[k];
        if (sous && typeof sous === 'object' && !Array.isArray(sous)) for (const k2 of Object.keys(sous).slice(0, 40)) { const c2 = ck + '.' + cleForme(k2); if (!cles[c2]) cles[c2] = typeDe(sous[k2]); }
      }
      if (Object.keys(cles).length >= 80) break;
    }
    return { chemin: trouve.chemin.slice(0, 120), n: trouve.liste.length, cles };
  };
  let nextVuPour = null;
  const noteNextConv = () => {
    try {
      if (!surPageConv()) return;
      const p = cheminNormalise(location.pathname).slice(0, 120);
      const pg = relConv.pages[p] || (Object.keys(relConv.pages).length < REL_CONV_PAGES_MAX ? (relConv.pages[p] = { n: 0 }) : null);
      if (pg && nextVuPour !== location.pathname) { pg.n++; pg.at = new Date().toISOString(); relConvDirty = true; }
      if (nextVuPour === location.pathname && relConv.next && relConv.next.messages) return;
      nextVuPour = location.pathname;
      const nd = document.getElementById('__NEXT_DATA__');
      const nf = self.__next_f;
      let txt = nd ? String(nd.textContent || '').slice(0, 2000000) : '';
      if (Array.isArray(nf)) for (const x of nf.slice(0, 500)) { if (Array.isArray(x) && typeof x[1] === 'string') txt += x[1]; if (txt.length > 4000000) break; }
      const r = { nextData: !!nd, nextF: Array.isArray(nf), messages: MOTIF_MESSAGES_TEXTE.test(txt) };
      const av = relConv.next;
      if (!av || av.nextData !== r.nextData || av.nextF !== r.nextF || av.messages !== r.messages) { relConv.next = Object.assign(r, { at: new Date().toISOString() }); relConvDirty = true; }
    } catch (_) {}
  };
  const noteConvPage = (method, url, status, ct, lireTexte) => {
    try {
      if (!surPageConv()) return;
      noteNextConv();
      let u; try { u = new URL(url, location.origin); } catch (_) { return; }
      if (!/^https?:$/.test(u.protocol) || !hoteVinted(u.hostname)) return;
      const hote = u.hostname === location.hostname ? '' : u.hostname;
      const cle = `${String(method || 'GET').toUpperCase()} ${hote}${cheminNormalise(u.pathname)}`.slice(0, 200);
      if (!relConv.req[cle] && Object.keys(relConv.req).length >= REL_CONV_REQ_MAX) return;
      const typeCt = String(ct || '').split(';')[0].trim().toLowerCase().slice(0, 60);
      const e = relConv.req[cle] || (relConv.req[cle] = {});
      e.st = Number(status) || 0; e.ct = typeCt; e.n = (e.n || 0) + 1; e.at = new Date().toISOString();
      relConvDirty = true;
      // Le corps n'est lu que pour une réponse 2xx de texte, une fois par chemin.
      if (e.messages || e.tete || !(e.st >= 200 && e.st < 300) || typeof lireTexte !== 'function') return;
      if (!/json|javascript|x-component|text\/plain/.test(typeCt)) return;
      // Lu TOUT DE SUITE (une copie du corps) : la page lit le sien juste après.
      let lecture; try { lecture = lireTexte(); } catch (_) { return; }
      Promise.resolve(lecture).then((t) => {
        try {
          if (typeof t !== 'string' || !t || t.length > 3000000) return;
          let j;
          if (/json/.test(typeCt) || /^[\[{]/.test(t.trim())) { try { j = JSON.parse(t); } catch (_) { j = undefined; } }
          const f = j !== undefined ? formeMessages(j) : null;
          if (j !== undefined) e.tete = formeTete(j);
          if (f) e.messages = f;
          else if (MOTIF_MESSAGES_TEXTE.test(t)) e.messages = { texte: true };
          relConvDirty = true;
          if (e.messages) setTimeout(flushSeen, 0);
        } catch (_) {}
      }).catch(() => {});
    } catch (_) {}
  };
  const noteCanal = (sorte, url) => {
    try {
      let u; try { u = new URL(String(url), location.href); } catch (_) { return null; }
      const cle = `${sorte} ${u.hostname}${cheminNormalise(u.pathname)}`.slice(0, 200);
      if (!relConv.canaux[cle] && Object.keys(relConv.canaux).length >= REL_CONV_CANAUX_MAX) return null;
      const c = relConv.canaux[cle] || (relConv.canaux[cle] = { ouvert: 0, trames: 0 });
      c.ouvert++; c.at = new Date().toISOString(); c.page = surPageConv() ? 'conversation' : 'autre';
      relConvDirty = true;
      return c;
    } catch (_) { return null; }
  };
  const noteTrame = (c, data) => {
    try {
      if (!c) return;
      c.trames++; relConvDirty = true;
      if (c.messages || c.trames > 200 || typeof data !== 'string' || !data || data.length > 500000) return;
      let j; try { j = JSON.parse(data); } catch (_) { return; }
      if (!c.tete) c.tete = formeTete(j);
      const f = formeMessages(j);
      if (f) { c.messages = f; setTimeout(flushSeen, 0); }
    } catch (_) {}
  };
  try {
    const WS0 = window.WebSocket;
    if (typeof WS0 === 'function' && typeof Proxy === 'function') {
      window.WebSocket = new Proxy(WS0, { construct(t, args, nt) {
        const ws = Reflect.construct(t, args, nt);
        try { const c = noteCanal('WS', args[0]); if (c) ws.addEventListener('message', (ev) => noteTrame(c, ev && ev.data)); } catch (_) {}
        return ws;
      } });
    }
    const ES0 = window.EventSource;
    if (typeof ES0 === 'function' && typeof Proxy === 'function') {
      window.EventSource = new Proxy(ES0, { construct(t, args, nt) {
        const es = Reflect.construct(t, args, nt);
        try { const c = noteCanal('ES', args[0]); if (c) es.addEventListener('message', (ev) => noteTrame(c, ev && ev.data)); } catch (_) {}
        return es;
      } });
    }
  } catch (_) {}
  const flushSeen = () => {
    noteNextConv();
    const avecChemins = seenDirty && (seenPaths.size || Object.keys(seenRep).length);
    if (!avecChemins && !relConvDirty) return;
    seenDirty = false;
    let conversation = relConvDirty ? JSON.parse(JSON.stringify(relConv)) : null;
    // Trop gros pour le fond (il jette au-delà de 200 000 caractères) : on retire
    // les formes de tête, jamais celles des messages.
    if (conversation && JSON.stringify(conversation).length > 180000) for (const e of Object.values(conversation.req || {})) delete e.tete;
    relConvDirty = false;
    // Les 300 chemins les PLUS RÉCENTS (l'ordre d'insertion d'un Set : le plus
    // ancien d'abord ; garder les premiers jetait ceux qu'on venait de voir).
    const msg = { kind: 'seen_urls', paths: Array.from(seenPaths).slice(-300), reponses: seenRep };
    if (conversation) msg.conversation = conversation;
    post(msg);
  };
  // Envoi RAPIDE puis régulier : une page Vinted est souvent quittée avant 60 s,
  // et le diagnostic ne partait alors jamais. On envoie à 5 s, puis toutes les
  // 20 s, et aussi quand tu quittes/masques la page (dernière chance).
  setTimeout(flushSeen, 5000);
  setInterval(flushSeen, 20000);
  try {
    window.addEventListener('pagehide', flushSeen);
    document.addEventListener('visibilitychange', () => { if (document.hidden) flushSeen(); });
  } catch (_) {}
  // La page elle-même est notée : c'est elle qui redirige quand un compte est
  // bloqué, et sans ça on ne sait même pas qu'il y est passé.
  try { noteSeen(location.href, 'PAGE', null); } catch (_) {}

  const sendHarvest = (url, text, method = 'GET', status = null) => {
    noteSeen(url);
    const h = matchHarvest(url);
    if (!h) return;
    if (h.type === 'notifications' && (String(method).toUpperCase() !== 'GET' || (status != null && (status < 200 || status >= 300)))) return;
    // On limite la taille pour ne pas saturer (les reponses Vinted sont petites).
    if (text && text.length < 800000) post({ kind: 'harvest', type: h.type, id: h.id, url, body: text,method:String(method).toUpperCase(),httpStatus:status });
  };

  // CAPTURE PASSIVE DES REQUETES D'ECRITURE. Toujours de l'OBSERVATION pure : on
  // note la forme des requetes que TU declenches quand tu agis sur Vinted
  // (baisser un prix, repondre a un message...). Ca sert a l'app pour reproduire
  // ensuite exactement la meme action en 1 clic, sans jamais deviner. On exclut
  // le bruit (tracking/metrics) et on ne garde que les vraies actions API.
  const WRITE_METHODS = /^(POST|PUT|PATCH|DELETE)$/i;
  const WRITE_NOISE = /(track|metric|event|impression|visit|telemetr|analytic|log|pageview|consent)/i;
  const contexteCreation = (method,url) => {
    try {const u=new URL(url,location.origin);if(String(method).toUpperCase()!=='POST'||u.pathname!=='/api/v2/conversations'||!/^(?:(?:www|api)\.)?vinted\.(fr|com|it|de)$/.test(u.hostname))return null;
      const lien=dernierFavoriClique&&Date.now()-dernierFavoriClique.at<=5000?dernierFavoriClique.url:lienContexteFavori(location.href);dernierFavoriClique=null;return lien;
    }catch{return null;}
  };
  const corpsRequestBorne = async request => {
    const lecteur=request.body?.getReader?.();if(!lecteur)return '';
    const blocs=[];let taille=0;
    try{for(;;){const {done,value}=await lecteur.read();if(done)break;taille+=value.byteLength;if(taille>100000){lecteur.cancel().catch(()=>{});return null;}blocs.push(value);}
      const total=new Uint8Array(taille);let pos=0;for(const b of blocs){total.set(b,pos);pos+=b.byteLength;}return new TextDecoder().decode(total);
    }finally{lecteur.releaseLock();}
  };
  const sendWriteReq = (method, url, body, contexteFavori=null) => {
    try {
      if (!WRITE_METHODS.test(method || '')) return;
      if (!/\/api\//.test(url || '')) return;
      if (WRITE_NOISE.test(url)) return;
      let b = body;
      if (b && typeof b !== 'string') {
        if (typeof URLSearchParams !== 'undefined' && b instanceof URLSearchParams) b = b.toString();
        else if (typeof FormData !== 'undefined' && b instanceof FormData) {
          // 1er oct. : la FORME de l'envoi (noms des champs, type et taille des
          // fichiers), jamais le contenu d'un fichier. C'est ce qui manque pour
          // renvoyer une photo lors d'une republication (POST /api/v2/photos).
          // Les valeurs texte courtes sont gardées (type, uuid temporaire) ;
          // les longues sont réduites à leur longueur.
          try {
            const parts = [];
            b.forEach((v, k) => {
              if (typeof File !== 'undefined' && v instanceof File) parts.push(k + '=Fichier(' + (v.type || '?') + ',' + v.size + 'o)');
              else { const t = String(v); parts.push(k + '=' + (t.length <= 40 ? t : '[' + t.length + ' car.]')); }
            });
            b = '[FormData] ' + parts.slice(0, 20).join(' & ');
          } catch (_) { b = '[FormData]'; }
        }
        else { try { b = JSON.stringify(b); } catch (_) { b = String(b); } }
      }
      if (b && b.length > 100000) b = b.slice(0, 100000);
      post({ kind: 'writereq', method: String(method).toUpperCase(), url, body: b || '', ...(contexteFavori?{contexteFavori}:{}) });
    } catch (_) {}
  };

  // ── UNE ANNONCE QUE TU SUPPRIMES SORT DE VRM TOUT DE SUITE (5.165) ──────────
  // Julien, 9 octobre : « je viens de supprimer beaucoup de paires et elles sont
  // encore marquées dans les annonces ». La seule trace était `writereq`, posée
  // AVANT la requête (donc aussi pour une suppression REFUSÉE) et sans statut —
  // et une ligne par compte, écrasée à chaque fois. Le statut, lui, ne partait
  // qu'au vidage du mouchard (5 s, 20 s) : une page qui navigue juste après le
  // 200 le perdait, et il ne portait pas l'identifiant (`{id}`).
  // ⇒ On regarde la RÉPONSE, dans son rappel (avant le code de Vinted qui
  //   navigue), et on ne retient qu'une suppression RÉUSSIE (2xx), sur Vinted,
  //   par son IDENTIFIANT d'annonce (§5) — jamais le corps, jamais un titre.
  //   C'est une LECTURE de ce que la page vient de faire sur SON clic : zéro
  //   requête de plus vers Vinted (§3).
  const RE_SUPPR = /^\/api\/v\d+\/items\/(\d{4,15})\/delete\/?$/;
  const noteSuppression = (method, url, status) => {
    try {
      if (String(method || '').toUpperCase() !== 'POST') return;
      const st = Number(status);
      if (!(st >= 200 && st < 300)) return;               // refusée, échouée : rien
      let U = null; try { U = new URL(url, location.origin); } catch (_) { return; }
      if (!/(^|\.)vinted\.[a-z.]+$/i.test(U.hostname)) return;
      const m = RE_SUPPR.exec(U.pathname);
      if (!m) return;
      post({ kind: 'suppression', itemId: m[1], status: st, at: new Date().toISOString() });
    } catch (_) {}
  };

  // ── LA PUBLICATION D'UNE ANNONCE (20 octobre, 5.201) ───────────────────────
  // Vinted crée l'annonce par `POST /api/v2/item_upload/items` (vu dans ses
  // chemins captés). On lit l'IDENTIFIANT de l'annonce dans la réponse (2xx
  // seulement) — c'est lui qui relie le numéro affiché à côté du bouton à
  // CETTE annonce (§5). Jamais un titre. Forme inconnue ⇒ on dit seulement
  // les NOMS de clés (rien de lié). (22 oct. : le corps envoyé part à part,
  // en `fiche`, pour sa description — voir `noteModification` juste après.)
  const RE_PUBLIE = /^\/api\/v\d+\/item_upload\/items\/?$/;
  const notePublication = (method, url, status, lireTexte, corps) => {
    try {
      if (String(method || '').toUpperCase() !== 'POST') return;
      const st = Number(status);
      if (!(st >= 200 && st < 300)) return;
      let U = null; try { U = new URL(url, location.origin); } catch (_) { return; }
      if (!/(^|\.)vinted\.[a-z.]+$/i.test(U.hostname) || !RE_PUBLIE.test(U.pathname)) return;
      Promise.resolve().then(lireTexte).then((t) => {
        let j = null; try { j = JSON.parse(t); } catch (_) {}
        const it = j && (j.item && typeof j.item === 'object' ? j.item : j);
        const id = it && it.id != null ? String(it.id) : '';
        if (/^\d{4,15}$/.test(id)) {
          post({ kind: 'publication', itemId: id, status: st });
          const tc = (typeof corps === 'string' && corps.length <= 100000) ? corps : '';   // 22 oct. : sa fiche, sous l'identifiant que Vinted vient de donner
          if (tc) post({ kind: 'fiche', itemId: id, status: st, via: 'publication', corps: tc });
        }
        else post({ kind: 'publication', itemId: null, status: st, cles: j && typeof j === 'object' ? Object.keys(j).slice(0, 12) : [] });
      }).catch(() => {});
    } catch (_) {}
  };

  // ── SA FICHE, TELLE QU'IL L'ENREGISTRE (22 octobre) ────────────────────────
  // Quand il publie (`POST …/item_upload/items`) ou MODIFIE une annonce
  // (`PUT …/item_upload/items/{id}`), la page envoie SA description et les codes
  // de CETTE annonce (catégorie, marque, couleurs, taille, état). On ne la
  // transmet qu'après un 2xx de Vinted, avec l'identifiant de l'ADRESSE (la
  // modification) ou de la RÉPONSE (la publication) — jamais un titre (§5).
  // Le fond n'en garde que la description et les codes (`noterFicheVinted`).
  // C'est une LECTURE de ce que la page vient de faire sur SON clic : zéro
  // requête de plus vers Vinted (§3).
  const RE_MODIF = /^\/api\/v\d+\/item_upload\/items\/(\d{4,15})\/?$/;
  const corpsTexte = (c) => (typeof c === 'string' && c.length <= 100000) ? c : '';
  const noteModification = (method, url, status, corps) => {
    try {
      if (String(method || '').toUpperCase() !== 'PUT') return;
      const st = Number(status);
      if (!(st >= 200 && st < 300)) return;
      let U = null; try { U = new URL(url, location.origin); } catch (_) { return; }
      if (!/(^|\.)vinted\.[a-z.]+$/i.test(U.hostname)) return;
      const m = RE_MODIF.exec(U.pathname);
      const t = corpsTexte(corps);
      if (!m || !t) return;
      post({ kind: 'fiche', itemId: m[1], status: st, via: 'modif', corps: t });
    } catch (_) {}
  };

  // ── SES BROUILLONS (28 octobre) ────────────────────────────────────────────
  // Mesuré dans ses requêtes : un brouillon s'enregistre par
  // `POST /api/v2/item_upload/drafts` (`{draft:{id:null,…}}`) et se met en ligne
  // par `POST …/drafts/{id}/completion` (même corps, `draft.id` posé). On garde le
  // CORPS qu'il vient d'enregistrer (2xx seulement), sous l'identifiant de la
  // RÉPONSE (création) ou de l'ADRESSE (mise à jour `…/drafts/{id}`) : c'est ce
  // qui permet ensuite de le mettre en ligne depuis VRM sans rien deviner.
  // Lecture de ce que la page vient de faire : zéro requête de plus (§3).
  const RE_BROUILLON = /^\/api\/v\d+\/item_upload\/drafts(?:\/(\d{4,15}))?\/?$/;
  // (29 oct., « elle n'a pas capté que j'avais fait passer un brouillon en ligne
  // à la main ») La mise en ligne d'un brouillon sur Vinted : `POST …/drafts/{id}/
  // completion` (vu dans ses requêtes). 2xx ⇒ ce brouillon est EN LIGNE.
  const RE_BROUILLON_FIN = /^\/api\/v\d+\/item_upload\/drafts\/(\d{4,15})\/completion\/?$/;
  const noteBrouillon = (method, url, status, lireTexte, corps) => {
    try {
      const mt = String(method || '').toUpperCase();
      if (mt !== 'POST' && mt !== 'PUT') return;
      const st = Number(status);
      if (!(st >= 200 && st < 300)) return;
      let U = null; try { U = new URL(url, location.origin); } catch (_) { return; }
      if (!/(^|\.)vinted\.[a-z.]+$/i.test(U.hostname)) return;
      const fin = RE_BROUILLON_FIN.exec(U.pathname);
      if (fin) { if (mt === 'POST') post({ kind: 'brouillonPublie', draftId: fin[1], status: st }); return; }
      const m = RE_BROUILLON.exec(U.pathname);
      const t = corpsTexte(corps);
      if (!m || !t) return;
      if (m[1]) { post({ kind: 'brouillon', draftId: m[1], status: st, corps: t }); return; }
      Promise.resolve().then(lireTexte).then((tx) => {
        let j = null; try { j = JSON.parse(tx); } catch (_) {}
        const d = j && ((j.draft && typeof j.draft === 'object') ? j.draft : (j.item && typeof j.item === 'object') ? j.item : j);
        const id = d && d.id != null ? String(d.id) : '';
        if (/^\d{4,15}$/.test(id)) post({ kind: 'brouillon', draftId: id, status: st, corps: t });
        else post({ kind: 'brouillon', draftId: null, status: st, cles: j && typeof j === 'object' ? Object.keys(j).slice(0, 12) : [] });
      }).catch(() => {});
    } catch (_) {}
  };

// <suivi-regle> — LA MÊME RÈGLE DANS inject.js ET background.js (§11), texte pour
// texte ; comparées par scripts/audit-suivi-vinted.cjs (23 octobre, 5.214).
// Le suivi que VINTED montre de SES commandes d'achat (le bouton « Suivre le
// colis » : `/transactions/{id}/shipment/journey_summary`, et la page d'une
// commande : `/escrow_orders/{id}/shipment`). Leur FORME n'a jamais été vue :
//  · `formeSuivi` — les NOMS de clés et les TYPES, jamais une valeur (une clé qui
//    ressemble à une donnée — e-mail, nombre de 3 chiffres ou plus, longue suite
//    hexadécimale, espace — devient `{k}`) ;
//  · `allegerSuivi` — une LISTE BLANCHE de noms de clés : statut, titre /
//    libellé / message, dates, transporteur, n° de suivi, nom du point relais.
//    Tout le reste (noms, adresses, e-mails, téléphones, codes de retrait, QR)
//    est RETIRÉ ; et un texte gardé qui CITE une valeur retirée (le nom du
//    destinataire, sa rue, le code) la perd aussi (`…`), comme une adresse
//    e-mail, un téléphone, « code 482913 », « 12 rue … », « 35000 Rennes » ;
//  · `contratSuivi` — ce qu'on en range (le CONTRAT de `harvest_{uid}_suivi_{tx}`) :
//    les étapes (30 au plus, la plus RÉCENTE en premier), la dernière DATÉE,
//    le transporteur et le n° de suivi s'ils y sont. Aucune étape reconnue ⇒
//    `null` : la forme est gardée, le contenu ne l'est pas (« pas su »). Une
//    étape sans date lisible n'est jamais « la dernière » (mieux vaut un blanc
//    qu'un faux) : sans date, rien ne sonne.
const SUIVI_TEXTES = ['title', 'status_title', 'state_title', 'event_title', 'label', 'libelle', 'status_label', 'state_label', 'event_label', 'headline', 'message', 'status_message', 'description', 'event_description', 'status_text', 'text', 'summary', 'subtitle'];
const SUIVI_CODES = ['status_code', 'event_code', 'state_code', 'event_type', 'status', 'state', 'statut', 'etat', 'step', 'step_type', 'event_status', 'current_status', 'shipment_status', 'tracking_status'];
const SUIVI_DATE = /(?:^|_)(?:date|time|datetime|timestamp|at|ts|heure|happened|occurred)(?:_|$)/i;
const SUIVI_LIMITE = /(?:^|_)(?:deadline|until|expires?|expiry|limit|limite|estimated|estimation|expected|eta|planned|promised|scheduled|prevue?|prevision(?:nelle)?)(?:_|$)/i;
// Une étape n'a eu lieu que si sa date est passée (quelques minutes d'horloge
// décalée tolérées) : une étape datée dans le FUTUR — une livraison estimée —
// n'est jamais « la dernière » et ne sonne jamais (revue du 24 octobre).
const SUIVI_FUTUR_MS = 10 * 60000;
// Un code ou un statut MACHINE (« at_pickup », « 4 », « in_transit ») : sans
// espace. Une valeur d'état qui n'en a pas la forme (« Code de retrait :
// 482913 ») est un TEXTE, et un texte se lave (revue du 24 octobre).
const SUIVI_CODE_MACHINE = /^[A-Za-z0-9_.:-]{1,40}$/;
const SUIVI_NUMERO = /^(?:tracking_code|tracking_number|tracking_no|tracking_id|parcel_number|parcel_tracking_number|shipment_tracking_code|numero_suivi|numero_de_suivi)$/i;
const SUIVI_TRANSP = /^(?:carrier|carrier_name|carrier_title|carrier_code|transporteur|courier|courier_name|shipping_provider|provider_name|delivery_company|shipping_company)$/i;
const SUIVI_PARENT_TRANSP = /(?:carrier|courier|transporteur|shipping_provider|provider)/i;
const SUIVI_PARENT_RELAIS = /(?:pickup|relay|relais|drop_?off|pudo|locker|parcel_?shop|service_?point)/i;
const SUIVI_PARENT_NUMERO = /^(?:tracking|suivi|parcel_tracking)$/i;
// Un parent qui désigne une PERSONNE (le contact du point relais, le
// destinataire, l'expéditeur) : son `name` n'est ni un transporteur ni un point
// relais, il reste dehors (revue du 24 octobre : « pickup_contact.name »).
const SUIVI_PARENT_PERSONNE = /(?:contact|person|recipient|destinataire|owner|user|customer|client|buyer|seller|sender|expediteur|receiver|holder|member|membre)/i;
const SUIVI_PERSO = /(?:^|_)(?:name|first_?name|last_?name|full_?name|surname|username|login|nickname|email|e_?mail|phone|phone_?number|telephone|tel|mobile|address|adresse|street|street_?name|line\d?|address_?line\d?|house_?number|city|ville|town|postal_?code|post_?code|zip|zip_?code|code|pickup_?code|collection_?code|pin|qr|qr_?code|barcode|password|token|iban)(?:_|$)/i;
const SUIVI_PAS_PERSO = /(?:country|currency|locale|language|lang|type|status|state)/i;
const SUIVI_TYPES = ['string', 'number', 'boolean', 'null', 'object', 'array'];
function suiviCleSure(k) {
  const s = String(k == null ? '' : k);
  return !!s && s.length <= 40 && !/@|\d{3,}|[0-9a-f]{16,}|\s/i.test(s);
}
function suiviDateIso(v, futurMs) {
  if (v == null || v === '' || typeof v === 'boolean') return null;
  let ms = NaN;
  if (typeof v === 'number') ms = v < 1e12 ? v * 1000 : v;
  else {
    const s = String(v).trim();
    if (/^\d{9,13}$/.test(s)) { const n = Number(s); ms = n < 1e12 ? n * 1000 : n; }
    else if (/^\d{4}-\d{2}-\d{2}/.test(s)) ms = Date.parse(s);
  }
  if (!Number.isFinite(ms) || ms < Date.UTC(2020, 0, 1) || ms > Date.now() + (futurMs == null ? 60 * 86400000 : futurMs)) return null;
  return new Date(ms).toISOString();
}
function suiviNumero(v) {
  const s = String(v == null ? '' : v).replace(/[\s-]/g, '').toUpperCase();
  return /^[A-Z0-9]{6,40}$/.test(s) && /\d/.test(s) ? s : null;
}
function nettoyerTexteSuivi(s, interdits) {
  let t = String(s == null ? '' : s).replace(/<[^>]*>/g, ' ').replace(/[\u0000-\u001f\u007f]+/g, ' ');
  for (const x of interdits || []) {
    const e = String(x).trim();
    if (e.length < 3) continue;
    t = t.replace(new RegExp(e.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), '…');
  }
  t = t.replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, '…')
    .replace(/(?:\+\d{2}\s?|\b0)[1-9](?:[\s.-]?\d{2}){4}\b/g, '…')
    .replace(/\b\d{1,4}\s*(?:bis|ter)?\s*,?\s*(?:rue|avenue|av\.?|bd|boulevard|chemin|place|all[ée]e|impasse|route|quai|cours|square|r[ée]sidence|lotissement|lieu[- ]dit)\b[^,.;\n]*/gi, '…')
    .replace(/\b\d{5}\s+[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]+(?:[ -][A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]+)*/g, '…')
    .replace(/((?:\b[Cc]ode|\bCODE|\bPIN|\b[Pp]in)(?:\s+(?:de\s+retrait|retrait|PIN|d['’]acc[èe]s))?\s*(?:[:：=]|est(?:\s+(?:le|la))?|is)?\s*)([A-Za-z0-9-]{4,})/g, (m, a, b) => (/\d/.test(b) ? a + '…' : m))
    .replace(/\b(remis(?:e|es)?\s+[àa]|d[ée]pos[ée](?:e|es|s)?\s+par|livr[ée](?:e|es|s)?\s+[àa])(?![a-zà-ÿ])\s*:?\s*(?:(?!\s(?:au|aux|en|dans|chez|depuis|via)\b)[^,.;\n…])+/gi, '$1 …');
  t = t.replace(/\s*(?:…\s*)+/g, ' … ').replace(/\s+/g, ' ').trim();
  return /^[…\s.,;:!?-]*$/.test(t) ? '' : t.slice(0, 200);
}
// Une feuille gardée : `{ sorte, v }`, ou `null` (retirée).
function suiviFeuille(cle, parent, v) {
  const k = String(cle).toLowerCase(), p = String(parent || '');
  if (!(typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean')) return null;
  if (SUIVI_PARENT_TRANSP.test(p) && !SUIVI_PARENT_PERSONNE.test(p) && /^(?:name|title|label|code)$/.test(k) && typeof v === 'string') return { sorte: 'texte', v };
  if (SUIVI_PARENT_RELAIS.test(p) && !SUIVI_PARENT_PERSONNE.test(p) && /^(?:name|title|label)$/.test(k) && typeof v === 'string') return { sorte: 'texte', v };
  if (SUIVI_PARENT_NUMERO.test(p) && /^(?:code|number|numero|id)$/.test(k)) { const n = suiviNumero(v); return n ? { sorte: 'numero', v: n } : null; }
  if (SUIVI_NUMERO.test(k)) { const n = suiviNumero(v); return n ? { sorte: 'numero', v: n } : null; }
  if (SUIVI_TRANSP.test(k)) return typeof v === 'string' ? { sorte: 'texte', v } : null;
  if (SUIVI_TEXTES.includes(k)) return typeof v === 'string' ? { sorte: 'texte', v } : null;
  if (SUIVI_CODES.includes(k)) {
    if (typeof v === 'string' && !SUIVI_CODE_MACHINE.test(v.trim())) return { sorte: 'texte', v };
    return { sorte: 'code', v };
  }
  if (SUIVI_DATE.test(k) || SUIVI_LIMITE.test(k)) { const d = suiviDateIso(v); return d ? { sorte: 'date', v: d } : null; }
  return null;
}
function allegerSuivi(racine) {
  const interdits = new Set(), aLaver = [];
  const marche = (v, parent, prof) => {
    if (prof > 8 || v == null) return undefined;
    if (Array.isArray(v)) {
      const out = [];
      for (const x of v.slice(0, 40)) { const r = marche(x, parent, prof + 1); if (r !== undefined) out.push(r); }
      return out.length ? out : undefined;
    }
    if (typeof v !== 'object') return undefined;
    const out = {};
    for (const k of Object.keys(v).slice(0, 80)) {
      const x = v[k];
      if (x && typeof x === 'object') {
        if (!suiviCleSure(k)) continue;
        const r = marche(x, k, prof + 1);
        if (r !== undefined) out[k] = r;
        continue;
      }
      const g = suiviCleSure(k) ? suiviFeuille(k, parent, x) : null;
      if (g) { out[k] = g.v; if (g.sorte === 'texte') aLaver.push([out, k]); continue; }
      if (typeof x === 'string' || typeof x === 'number') {
        const s = String(x).trim();
        if (s.length >= 3 && ((SUIVI_PERSO.test(k) && !SUIVI_PAS_PERSO.test(k)) || /[\w.+-]+@[\w-]+\.[\w-]+/.test(s))) interdits.add(s.slice(0, 200));
      }
    }
    return Object.keys(out).length ? out : undefined;
  };
  const garde = marche(racine, '', 0) || {};
  const liste = [...interdits].sort((a, b) => b.length - a.length);
  for (const [o, k] of aLaver) {
    const t = nettoyerTexteSuivi(o[k], liste);
    if (t) o[k] = t; else delete o[k];
  }
  return garde;
}
function formeSuivi(racine) {
  const out = {};
  let n = 0;
  const poser = (c, t) => {
    if (out[c] === undefined) { if (n < 200) { out[c] = t; n++; } return; }
    if (!out[c].split('|').includes(t)) out[c] = (out[c] + '|' + t).slice(0, 60);
  };
  const marche = (v, chemin, prof) => {
    if (prof > 8) return;
    if (Array.isArray(v)) {
      if (!v.length) { poser(chemin || '(racine)', 'array'); return; }
      for (const x of v.slice(0, 5)) marche(x, chemin + '[]', prof + 1);
      return;
    }
    if (v && typeof v === 'object') {
      const cles = Object.keys(v);
      if (!cles.length) { poser(chemin || '(racine)', 'object'); return; }
      for (const k of cles.slice(0, 80)) marche(v[k], (chemin ? chemin + '.' : '') + (suiviCleSure(k) ? k : '{k}'), prof + 1);
      return;
    }
    poser(chemin || '(racine)', v === null ? 'null' : typeof v);
  };
  marche(racine, '', 0);
  return out;
}
// La forme reçue d'une page (ou d'un message forgé) : seulement des chemins de
// noms de clés sûrs et des types connus — jamais une valeur.
function nettoyerFormeSuivi(f) {
  const out = {};
  if (!f || typeof f !== 'object' || Array.isArray(f)) return out;
  let n = 0;
  for (const c of Object.keys(f)) {
    if (n >= 200) break;
    const t = String(f[c] == null ? '' : f[c]);
    if (!/^[A-Za-z0-9_.[\]{}()-]{1,160}$/.test(c) || /\d{3,}|@/.test(c)) continue;
    if (!t || !t.split('|').every((x) => SUIVI_TYPES.includes(x))) continue;
    out[c] = t.slice(0, 60); n++;
  }
  return out;
}
function suiviVal(o, cle) {
  for (const k of Object.keys(o)) if (k.toLowerCase() === cle) return o[k];
  return undefined;
}
function suiviEtape(o) {
  if (!o || typeof o !== 'object' || Array.isArray(o)) return null;
  let t = '';
  for (const k of SUIVI_TEXTES) { const x = suiviVal(o, k); if (typeof x === 'string' && x.trim()) { t = x.trim(); break; } }
  if (!t) return null;
  let at = null, futur = false;
  for (const k of Object.keys(o)) {
    if (!SUIVI_DATE.test(k) || SUIVI_LIMITE.test(k)) continue;
    const d = suiviDateIso(o[k], SUIVI_FUTUR_MS);
    if (d) { at = d; break; }
    if (suiviDateIso(o[k])) futur = true;
  }
  // Datée seulement dans l'avenir : une prévision, pas une étape.
  if (!at && futur) return null;
  let code = null;
  for (const k of SUIVI_CODES) {
    const x = suiviVal(o, k);
    if ((typeof x === 'string' && SUIVI_CODE_MACHINE.test(x.trim()) && x !== t) || typeof x === 'number') { code = String(x).trim(); break; }
  }
  return { t: t.slice(0, 200), at, code };
}
function contratSuivi(a) {
  if (!a || typeof a !== 'object') return null;
  const groupes = [], seuls = [];
  const dansGroupe = new Set();
  const marche = (v, prof) => {
    if (prof > 8 || !v || typeof v !== 'object') return;
    if (Array.isArray(v)) {
      const g = [];
      for (const x of v) { const e = suiviEtape(x); if (e) { g.push(e); dansGroupe.add(x); } }
      if (g.length) groupes.push(g);
      for (const x of v) marche(x, prof + 1);
      return;
    }
    for (const k of Object.keys(v)) marche(v[k], prof + 1);
  };
  marche(a, 0);
  const objets = (v, prof) => {
    if (prof > 8 || !v || typeof v !== 'object') return;
    if (Array.isArray(v)) { for (const x of v) objets(x, prof + 1); return; }
    if (!dansGroupe.has(v)) { const e = suiviEtape(v); if (e && e.at) seuls.push(e); }
    for (const k of Object.keys(v)) objets(v[k], prof + 1);
  };
  objets(a, 0);
  if (seuls.length) groupes.push(seuls);
  const score = (g) => g.filter((e) => e.at).length * 100 + g.length;
  let meilleur = null;
  for (const g of groupes) if (!meilleur || score(g) > score(meilleur)) meilleur = g;
  if (!meilleur || !meilleur.length) return null;
  const vues = new Set(), etapes = [];
  for (const e of meilleur) { const c = `${e.at || ''}|${e.t}|${e.code || ''}`; if (!vues.has(c)) { vues.add(c); etapes.push(e); } }
  const datees = etapes.filter((e) => e.at).sort((x, y) => Date.parse(y.at) - Date.parse(x.at));
  const sansDate = etapes.filter((e) => !e.at);
  const toutes = datees.concat(sansDate).slice(0, 30);
  let transporteur = null, suivi = null;
  const cherche = (v, parent, prof) => {
    if (prof > 8 || !v || typeof v !== 'object') return;
    if (Array.isArray(v)) { for (const x of v) cherche(x, parent, prof + 1); return; }
    for (const k of Object.keys(v)) {
      const x = v[k], kl = k.toLowerCase();
      if (x && typeof x === 'object') { cherche(x, k, prof + 1); continue; }
      if (!transporteur && typeof x === 'string' && x.trim() && !/^\d+$/.test(x.trim())
          && ((SUIVI_PARENT_TRANSP.test(String(parent || '')) && !SUIVI_PARENT_PERSONNE.test(String(parent || '')) && /^(?:name|title|label)$/.test(kl)) || /^(?:carrier|carrier_name|carrier_title|transporteur|courier|courier_name|shipping_provider|provider_name|delivery_company|shipping_company)$/.test(kl))) transporteur = x.trim().slice(0, 80);
      if (!suivi && (SUIVI_NUMERO.test(kl) || (SUIVI_PARENT_NUMERO.test(String(parent || '')) && /^(?:code|number|numero|id)$/.test(kl)))) suivi = suiviNumero(x);
    }
  };
  cherche(a, '', 0);
  return { etapes: toutes, dernier: datees.length ? datees[0] : null, transporteur, suivi };
}
// </suivi-regle>

  // ── LE SUIVI QUE VINTED MONTRE DE SES ACHATS (23 octobre, 5.214) ──────────
  // Julien : « enregistrer le numéro de suivi et tracer le colis » ; « que ça me
  // prévienne dès qu'il y a une mise à jour d'un colis ». Les transporteurs
  // n'ouvrent rien de gratuit (mesuré) ; la meilleure source est le suivi que
  // VINTED montre de SES commandes d'achat. Son navigateur a déjà vu passer
  // (chemin + statut, jamais le contenu) : `…/transactions/{id}/shipment/
  // journey_summary` (le bouton « Suivre le colis »), `…/escrow_orders/{id}/
  // shipment` (la page d'une commande) et `…/parcel_collection_code`. Leur FORME
  // n'a jamais été vue. On regarde la RÉPONSE que la page vient de recevoir —
  // AUCUNE requête de plus (§3) — et il ne part d'ici que :
  //   · la FORME (noms de clés + types, jamais une valeur) ;
  //   · pour le suivi et l'expédition, le contenu ALLÉGÉ par liste blanche
  //     (`allegerSuivi`, bloc <suivi-regle> : rien d'un nom, d'une adresse, d'un
  //     e-mail, d'un téléphone, d'un code de retrait ni d'un QR) ;
  //   · pour le code de retrait : la forme SEULEMENT — le code lui-même reste
  //     rangé par le chemin existant (la conversation), rien de plus.
  // C'est le fond qui décide si la transaction est un ACHAT de CE compte
  // (identité) ; une vente n'y laisse que sa forme.
  const RE_SUIVI = [
    [/^\/api\/v\d+\/transactions\/(\d{4,20})\/shipment\/journey_summary\/?$/, 'journey'],
    [/^\/api\/v\d+\/escrow_orders\/(\d{4,20})\/shipment\/?$/, 'escrow'],
    [/^\/api\/v\d+\/transactions\/(\d{4,20})\/shipment\/parcel_collection_code\/?$/, 'code'],
  ];
  // `transaction_id` à la racine ou un niveau plus bas : une IDENTITÉ lue dans la
  // réponse (l'identifiant d'une commande « escrow » n'est peut-être pas celui de
  // la transaction — le fond essaie les deux, et ne garde que celui qui est un
  // achat de ce compte).
  const txDuCorps = (j) => {
    const essai = (o) => (o && typeof o === 'object' && !Array.isArray(o) && /^\d{4,20}$/.test(String(o.transaction_id == null ? '' : o.transaction_id))) ? String(o.transaction_id) : '';
    if (essai(j)) return essai(j);
    if (j && typeof j === 'object' && !Array.isArray(j)) for (const k of Object.keys(j)) { const t = essai(j[k]); if (t) return t; }
    return '';
  };
  // 5.243 (Julien, 27 oct. : « l'extension doit s'adapter à la différence entre
  // les catégories Vinted et Vestiaire ») : l'ARBRE des catégories Vinted
  // (`GET /api/v2/item_upload/catalogs`, chargé par la page de dépôt — vu dans
  // ses chemins). Des libellés PUBLICS du site, aucune personne : gardé entier.
  let catalogueVu = 0;
  const noteCatalogueVinted = (method, url, status, lireTexte) => {
    try {
      if (String(method || 'GET').toUpperCase() !== 'GET' || !(Number(status) >= 200 && Number(status) < 300)) return;
      let U = null; try { U = new URL(url, location.origin); } catch (_) { return; }
      if (!/(^|\.)vinted\.[a-z.]+$/i.test(U.hostname) || !/^\/api\/v\d+\/item_upload\/catalogs\/?$/.test(U.pathname)) return;
      Promise.resolve().then(lireTexte).then((t) => {
        if (typeof t !== 'string' || t.length < 2 || t.length > 3000000 || t.length === catalogueVu) return;
        let j = null; try { j = JSON.parse(t); } catch (_) { return; }
        if (!j || typeof j !== 'object' || (typeof j.code === 'number' && j.code !== 0)) return;
        catalogueVu = t.length;
        post({ kind: 'catalogueVinted', body: t });
      }).catch(() => {});
    } catch (_) {}
  };
  // 5.266 : la LISTE des couleurs de Vinted (`GET /api/v2/item_upload/colors`,
  // chargée par la page de dépôt). Id et nom seulement : des libellés publics.
  let couleursVu = 0;
  const noteCouleursVinted = (method, url, status, lireTexte) => {
    try {
      if (String(method || 'GET').toUpperCase() !== 'GET' || !(Number(status) >= 200 && Number(status) < 300)) return;
      let U = null; try { U = new URL(url, location.origin); } catch (_) { return; }
      if (!/(^|\.)vinted\.[a-z.]+$/i.test(U.hostname) || !/^\/api\/v\d+\/item_upload\/colors\/?$/.test(U.pathname)) return;
      Promise.resolve().then(lireTexte).then((t) => {
        if (typeof t !== 'string' || t.length < 2 || t.length > 200000 || t.length === couleursVu) return;
        let j = null; try { j = JSON.parse(t); } catch (_) { return; }
        const liste = Array.isArray(j) ? j : (j && Array.isArray(j.colors) ? j.colors : (j && Array.isArray(j.item_colors) ? j.item_colors : null));
        if (!liste) return;
        couleursVu = t.length;
        post({ kind: 'couleursVinted', couleurs: liste.slice(0, 80).map((c) => ({ id: c && c.id, title: c && (c.title != null ? c.title : c.name) })) });
      }).catch(() => {});
    } catch (_) {}
  };
  const noteSuivi = (method, url, status, lireTexte) => {
    try {
      if (String(method || 'GET').toUpperCase() !== 'GET') return;
      const st = Number(status);
      if (!(st >= 200 && st < 300)) return;
      let U = null; try { U = new URL(url, location.origin); } catch (_) { return; }
      if (!/(^|\.)vinted\.[a-z.]+$/i.test(U.hostname)) return;
      let quoi = null, id = null;
      for (const [re, q] of RE_SUIVI) { const m = re.exec(U.pathname); if (m) { quoi = q; id = m[1]; break; } }
      if (!quoi) return;
      Promise.resolve().then(lireTexte).then((t) => {
        if (typeof t !== 'string' || !t || t.length > 400000) return;
        let j = null; try { j = JSON.parse(t); } catch (_) { return; }
        if (!j || typeof j !== 'object') return;
        if (typeof j.message_code === 'string' && typeof j.code === 'number' && j.code !== 0) return;   // un refus de Vinted n'est pas une forme
        if (typeof j.code === 'string' && j.code && Object.keys(j).every((k) => /^(code|message|message_code|errors|error|status|details)$/.test(k))) return;   // 5.246 : refus à code texte (« UNAUTHORIZED »)
        const msg = { kind: 'suivi', quoi, id, forme: formeSuivi(j) };
        if (quoi !== 'code') { msg.allege = allegerSuivi(j); const tc = txDuCorps(j); if (tc) msg.txCorps = tc; }
        post(msg);
      }).catch(() => {});
    } catch (_) {}
  };

  // Convertit un ArrayBuffer en base64 (par morceaux pour eviter le débordement
  // de pile sur les gros PDF).
  const abToB64 = (buf) => {
    let binary = '';
    const bytes = new Uint8Array(buf);
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  };
  // Capture un BORDEREAU (PDF) que Vinted renvoie quand tu le telecharges. On
  // repere par le content-type application/pdf (l'URL du label n'est pas connue
  // d'avance). Sert a tamponner automatiquement le bordereau cote app.
  // Un PDF de FACTURE / REÇU (compta pro) se distingue du bordereau par son URL.
  const RECEIPT_URL = /invoice|receipt|facture|re[çc]u|billing|document/i;
  const maybeCaptureLabel = (contentType, url, getArrayBuffer) => {
    try {
      if (!/application\/pdf/i.test(contentType || '')) return;
      const isReceipt = RECEIPT_URL.test(url || '');
      getArrayBuffer().then((buf) => {
        // Les OCTETS d'un PDF (`%PDF`), pas seulement l'en-tête : une page de
        // session expirée servie en `application/pdf` n'est pas un bordereau.
        const t = buf && buf.byteLength >= 4 ? new Uint8Array(buf, 0, 4) : null;
        const estPdf = !!(t && t[0] === 0x25 && t[1] === 0x50 && t[2] === 0x44 && t[3] === 0x46);
        if (estPdf && buf.byteLength < 4000000) {
          post({ kind: isReceipt ? 'receipt' : 'label', url, b64: abToB64(buf) });
        }
      }).catch(() => {});
    } catch (_) {}
  };

  // --- Patch de fetch ---
  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input, init) {
      try {
        const url = (typeof input === 'string') ? input : input instanceof URL ? input.href : (input && input.url) || '';
        if (init && init.headers) sendCsrf(init.headers);
        else if (input && input.headers) sendCsrf(input.headers);
        const method = (init && init.method) || (input && input.method) || 'GET';
        const corpsEnvoye = init && init.body;
        const contexte=contexteCreation(method,url);
        const estCreation=String(method).toUpperCase()==='POST'&&/\/api\/v2\/conversations(?:\?|$)/.test(url);
        if(estCreation&&corpsEnvoye===undefined&&typeof Request!=='undefined'&&input instanceof Request){
          try{const copie=input.clone();corpsRequestBorne(copie).then(body=>{if(body!==null)sendWriteReq(method,url,body,contexte);}).catch(()=>{});}catch{}
        }else sendWriteReq(method, url, corpsEnvoye,contexte);
        const p = origFetch.apply(this, arguments);
        noteSeen(url); // diagnostic : TOUT appel API, pas seulement ceux qui matchent
        p.then((res) => {
          try {
            noteSuppression(method, url, res.status);   // 5.165 : AVANT tout le reste (la page va naviguer)
            notePublication(method, url, res.status, () => res.clone().text(), corpsEnvoye);   // 5.201
            noteModification(method, url, res.status, corpsEnvoye);   // 22 oct.
            noteBrouillon(method, url, res.status, () => res.clone().text(), corpsEnvoye);   // 28 oct.
            noteCatalogueVinted(method, url, res.status, () => res.clone().text());
            noteCouleursVinted(method, url, res.status, () => res.clone().text());
            noteSuivi(method, url, res.status, () => res.clone().text());   // 5.214 : le suivi Vinted de ses achats
            noteSeen(url, method, res.status);          // le STATUT, pas seulement le chemin
            const ct = (res.headers && res.headers.get) ? (res.headers.get('content-type') || '') : '';
            noteConvPage(method, url, res.status, ct, () => res.clone().text());   // 29 oct. : la route des messages
            if (/application\/pdf/i.test(ct)) {
              maybeCaptureLabel(ct, url, () => res.clone().arrayBuffer());
            } else if (url && matchHarvest(url)) {
              res.clone().text().then((t) => sendHarvest(url, t, method, res.status)).catch(() => {});
            }
          } catch (_) {}
        }).catch(() => {});
        return p;
      } catch (_) {
        return origFetch.apply(this, arguments);
      }
    };
  }

  // --- Patch de XMLHttpRequest ---
  const XHR = window.XMLHttpRequest;
  if (XHR) {
    const origOpen = XHR.prototype.open;
    const origSend = XHR.prototype.send;
    const origSetHeader = XHR.prototype.setRequestHeader;
    XHR.prototype.open = function (method, url) {
      this.__cancaleUrl = typeof url==='string'?url:String(url||'');
      this.__cancaleMethod = method;
      return origOpen.apply(this, arguments);
    };
    XHR.prototype.setRequestHeader = function (name, value) {
      try { if (String(name).toLowerCase() === 'x-csrf-token' && value) post({ kind: 'csrf', csrf: value }); } catch (_) {}
      return origSetHeader.apply(this, arguments);
    };
    XHR.prototype.send = function (bodyArg) {
      try {
        const url = this.__cancaleUrl || '';
        // Capte aussi le csrf/anon posé via setRequestHeader (déjà relayé plus
        // haut) pour la moisson active.
        sendWriteReq(this.__cancaleMethod, url, bodyArg,contexteCreation(this.__cancaleMethod,url));
        noteSeen(url); // diagnostic : TOUT appel API (XHR aussi)
        this.addEventListener('load', function () {
          try {
            noteSuppression(this.__cancaleMethod, url, this.status);   // 5.165
            notePublication(this.__cancaleMethod, url, this.status, () => (typeof this.responseText === 'string' ? this.responseText : ''), bodyArg);   // 5.201
            noteModification(this.__cancaleMethod, url, this.status, bodyArg);   // 22 oct.
            noteBrouillon(this.__cancaleMethod, url, this.status, () => (typeof this.responseText === 'string' ? this.responseText : ''), bodyArg);   // 28 oct.
            noteCatalogueVinted(this.__cancaleMethod, url, this.status, () => { try { if (this.responseType === 'json') return JSON.stringify(this.response); return typeof this.responseText === 'string' ? this.responseText : ''; } catch (_) { return ''; } });
            noteCouleursVinted(this.__cancaleMethod, url, this.status, () => { try { if (this.responseType === 'json') return JSON.stringify(this.response); return typeof this.responseText === 'string' ? this.responseText : ''; } catch (_) { return ''; } });
            noteSuivi(this.__cancaleMethod, url, this.status, () => { try { if (this.responseType === 'json') return JSON.stringify(this.response); return typeof this.responseText === 'string' ? this.responseText : ''; } catch (_) { return ''; } });   // 5.214
            noteSeen(url, this.__cancaleMethod, this.status);   // le STATUT aussi
            const ct = this.getResponseHeader ? (this.getResponseHeader('content-type') || '') : '';
            noteConvPage(this.__cancaleMethod, url, this.status, ct, () => { try { if (this.responseType === 'json') return JSON.stringify(this.response); return typeof this.responseText === 'string' ? this.responseText : ''; } catch (_) { return ''; } });   // 29 oct.
            // Bordereau PDF via XHR (si Vinted le charge en binaire).
            if (/application\/pdf/i.test(ct) && this.response && this.response.byteLength) {
              maybeCaptureLabel(ct, url, () => Promise.resolve(this.response));
            } else if (url && matchHarvest(url) && typeof this.responseText === 'string') {
              sendHarvest(url, this.responseText, this.__cancaleMethod, this.status);
            }
          } catch (_) {}
        });
      } catch (_) {}
      return origSend.apply(this, arguments);
    };
  }

  // ── MOISSON ACTIVE (v3.8) ──────────────────────────────────────────────────
  // Vinted construit désormais le dressing et les commandes CÔTÉ SERVEUR : la
  // page ne fait plus l'appel /wardrobe/items ni /my_orders, donc il n'y a plus
  // rien à intercepter passivement. On rétablit la moisson en faisant l'appel
  // NOUS-MÊMES — mais depuis TON navigateur, TON IP, TA session (cookies inclus
  // automatiquement). C'est exactement la requête que le site faisait avant :
  // indistinguable de toi. C'était la piste prévue de longue date (porter les
  // appels par l'extension plutôt que par l'IP serveur de Vercel).
  // Garde-fous « profil humain » : au plus une fois toutes les 30 min, seulement
  // quand l'onglet est visible, un léger délai aléatoire, un seul compte (celui
  // connecté dans cet onglet). Se rabat en silence si un endpoint a disparu.
  const ACTIVE_TTL = 30 * 60 * 1000;
  const jitter = (min, max) => min + Math.random() * (max - min);
  // ⚠️ 5.162 — L'ARRÊT NET SUR 429 / 403. Cette moisson part DE LA PAGE, hors
  // de la file du fond : quand Vinted répondait « ralentis » (429) ou « non »
  // (403), chaque boucle cassait la sienne et la suivante repartait (ventes,
  // achats, boîte : des dizaines de requêtes après le refus). Désormais le
  // premier frein ARRÊTE tout ce qui reste de cette moisson, et le fond en est
  // prévenu (`vintedFrein`) : il pose la même pause que pour ses propres
  // requêtes. Et une moisson ne DÉMARRE pas pendant une pause : `content.js`
  // nous transmet sa fin (`CANCALE_VINTED_PAUSE`).
  let freinVinted = 0;
  let pauseJusqua = 0;
  try {
    window.addEventListener('message', (e) => {
      try {
        if (e.source !== window || !e.data || e.data.__tag !== 'CANCALE_VINTED_PAUSE') return;
        pauseJusqua = Number(e.data.jusqua) || 0;
      } catch (_) {}
    }, false);
  } catch (_) {}
  // ── LE RELAIS DE LA PAGE (20 octobre, Orion iPhone) ──────────────────────
  // Un navigateur sans `scripting` (ou sans monde MAIN) ne peut pas injecter
  // une fonction ici : le fond demande alors UNE requête GET, relayée par
  // content.js, et on la fait d'ici — exactement ce que la fonction injectée
  // aurait fait sur Chrome (même page, mêmes cookies). Seulement un chemin
  // relatif de l'API Vinted, seulement en lecture ; la réponse repart par le
  // même relais. Sur Chrome personne ne l'appelle.
  try {
    window.addEventListener('message', async (e) => {
      try {
        if (e.source !== window || !e.data || e.data.__tag !== 'CANCALE_VINTED_REQ') return;
        const id = String(e.data.id || ''), p = String(e.data.p || '');
        if (!id || !/^\/(api|web\/api)\//.test(p)) return;
        const h = {};
        const src = e.data.h && typeof e.data.h === 'object' ? e.data.h : {};
        for (const k of Object.keys(src)) if (/^(accept|x-csrf-token)$/i.test(k)) h[k] = String(src[k]);
        let out = { status: 0, ok: false, json: null };
        try {
          const r = await window.fetch(p, { credentials: 'include', headers: h });
          let json = null; try { json = await r.json(); } catch (_) {}
          out = { status: r.status, ok: r.ok, json };
        } catch (_) {}
        window.postMessage({ __tag: 'CANCALE_VINTED_REP', id, status: out.status, ok: out.ok, json: out.json, origine: location.origin }, location.origin);
      } catch (_) {}
    }, false);
  } catch (_) {}
  const apiGet = async (path) => {
    if (freinVinted) return null;                         // Vinted a freiné : plus rien ne part
    try {
      const h = { accept: 'application/json' };
      if (lastCsrf) h['x-csrf-token'] = lastCsrf;
      if (lastAnon) h['x-anon-id'] = lastAnon;
      const r = await fetch(path, { credentials: 'include', headers: h });
      if (r && (r.status === 429 || r.status === 403)) {
        freinVinted = r.status;
        post({ kind: 'vintedFrein', statut: r.status });
        return null;
      }
      if (!r || !r.ok) return null;
      return await r.text();
    } catch (_) { return null; }
  };
  const activeHarvest = async () => {
    try {
      if (!/(^|\.)vinted\./i.test(location.host)) return; // uniquement sur Vinted
      if (document.hidden) return;                        // onglet au premier plan seulement
      if (Date.now() < pauseJusqua) return;               // Vinted a demandé de ralentir (5.162)
      freinVinted = 0;                                    // nouvelle moisson, hors pause
      const KEY = '__cancale_active_ts';
      let last = 0; try { last = +(localStorage.getItem(KEY) || 0); } catch (_) {}
      if (Date.now() - last < ACTIVE_TTL) return;
      try { localStorage.setItem(KEY, String(Date.now())); } catch (_) {}
      // 1) profil (donne l'ID de dressing, ≠ id de compte).
      const who = await apiGet('/api/v2/users/current');
      let pid = null;
      if (who) { sendHarvest('/api/v2/users/current', who); try { pid = JSON.parse(who).user.id; } catch (_) {} }
      // 2) annonces en ligne (dressing).
      if (pid) {
        await new Promise(r => setTimeout(r, jitter(600, 1500)));
        // TOUTES les pages : Vinted plafonne per_page (~96 malgre le 200
        // demande). Un compte de 604 articles ne rendait que sa 1re page, et
        // l'app croyait le reste disparu.
        let tout = null;
        for (let page = 1; page <= 10; page++) {
          const w = await apiGet(`/api/v2/wardrobe/${pid}/items?page=${page}&per_page=200&order=relevance`);
          if (!w) break;
          let j = null; try { j = JSON.parse(w); } catch (_) { break; }
          const lot = Array.isArray(j.items) ? j.items : null;
          if (!lot) break;
          if (!tout) tout = j; else tout.items = tout.items.concat(lot);
          const tp = j.pagination && j.pagination.total_pages;
          if (!lot.length || (tp && page >= tp)) break;
          await new Promise(r => setTimeout(r, jitter(600, 1500)));
        }
        if (tout) sendHarvest(`/api/v2/wardrobe/${pid}/items`, JSON.stringify(tout));
      }
      // 2b) ⚠️ RETIRÉ — 6 REQUÊTES PAR VISITE POUR RIEN.
      //     On demandait ici le détail de 6 annonces par passage
      //     (`GET /api/v2/items/{id}`), avec une pause de 0,9–2,2 s entre
      //     chacune, en espérant récupérer la DESCRIPTION.
      //     Le compteur de diagnostic (`panel_diag_capture`, relevé du 24 août)
      //     est sans appel :
      //         recu_item = 73   ·   abandon_json_item = 73   ·   ecrit_item = 0
      //     73 tentatives, 73 échecs, ZÉRO ligne écrite. La cause est connue
      //     depuis §5.26 : Vinted renvoie sur cette URL une PAGE D'ERREUR HTML
      //     avec un statut 200, donc `apiGet` la laisse passer et `JSON.parse`
      //     casse. L'endpoint ne rend plus la fiche, point.
      //     Ce que ça coûtait à chaque visite sur Vinted : 6 appels inutiles,
      //     6 à 13 secondes de retard sur la vraie moisson, et 6 requêtes de
      //     plus dans l'empreinte du compte — le signal qu'on passe justement
      //     notre temps à réduire (§5, §48).
      //     ⚠️ Rien n'est perdu : la DESCRIPTION arrive par la lecture de la
      //     PAGE (`readListingDetailFromPage` → `vinted_item_details`), qui
      //     fonctionne, et c'est elle que le coffre et « Republier » lisent
      //     (§5.10, §5.50). Le bouton manuel « 📥 Récupérer le texte »
      //     (`capterAnnonce`) reste disponible si Vinted rétablit un jour
      //     l'endpoint — il le dira tout seul en écrivant une ligne.
      //     NE PAS remettre cette boucle sans avoir vu `ecrit_item > 0`.
      // 3) ventes + achats — TOUTES les pages (comme le dressing en 2).
      // ⚠️ Avant : seulement `page=1&per_page=100` → un vendeur de 300 ventes ne
      // rendait QUE ses 100 dernières, le reste n'arrivait JAMAIS dans l'app.
      // On concatène toutes les pages en UN SEUL envoi : `storeHarvest` garde la
      // capture la plus RICHE (`listePlusRiche` compare le nombre d'items), donc
      // une liste partielle n'écrase jamais une complète — mais il faut lui
      // donner la liste complète d'un coup, des pages envoyées séparément
      // s'écraseraient l'une l'autre (pas d'union côté fond). Mêmes garde-fous
      // que le dressing : une requête à la fois, délai humain entre chacune,
      // plafond de pages, et tout ça au plus une fois / 30 min (ACTIVE_TTL).
      // ⚠️ « purchased » et PAS « bought » : ?type=bought renvoie chez certains
      // comptes les ventes (vérifié en base) → des ventes dans les achats.
      for (const t of ['sold', 'purchased']) {
        let tout = null;
        for (let page = 1; page <= 20; page++) {
          await new Promise(r => setTimeout(r, jitter(600, 1500)));
          const o = await apiGet(`/api/v2/my_orders?type=${t}&page=${page}&per_page=100`);
          if (!o) break;
          let j = null; try { j = JSON.parse(o); } catch (_) { break; }
          const lot = Array.isArray(j.my_orders) ? j.my_orders : null;
          if (!lot) break;
          if (!tout) tout = j; else tout.my_orders = tout.my_orders.concat(lot);
          const tp = j.pagination && j.pagination.total_pages;
          if (lot.length < 100 || !lot.length || (tp && page >= tp)) break;
        }
        if (tout) sendHarvest(`/api/v2/my_orders?type=${t}`, JSON.stringify(tout));
      }
      // 4) boîte de réception — TOUTES les pages aussi (avant : 50 max).
      {
        let tout = null;
        for (let page = 1; page <= 15; page++) {
          await new Promise(r => setTimeout(r, jitter(600, 1500)));
          const inb = await apiGet(`/api/v2/inbox?page=${page}&per_page=50`);
          if (!inb) break;
          let j = null; try { j = JSON.parse(inb); } catch (_) { break; }
          const lot = Array.isArray(j.conversations) ? j.conversations : null;
          if (!lot) break;
          if (!tout) tout = j; else tout.conversations = tout.conversations.concat(lot);
          const tp = j.pagination && j.pagination.total_pages;
          if (lot.length < 50 || !lot.length || (tp && page >= tp)) break;
        }
        if (tout) sendHarvest('/api/v2/inbox', JSON.stringify(tout));
      }
    } catch (_) {}
  };
  // Lancement différé (laisse la page s'installer et le csrf se capter), puis à
  // chaque retour au premier plan (throttlé par ACTIVE_TTL).
  setTimeout(activeHarvest, 6000);
  try { document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(activeHarvest, 3000); }); } catch (_) {}
  post({kind:'injectReady'});
})();
